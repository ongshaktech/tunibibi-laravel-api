<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SellerPaymentsController extends Controller
{
    //
}
