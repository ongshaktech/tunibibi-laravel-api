<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FeaturedShopController extends Controller
{
    //
}
