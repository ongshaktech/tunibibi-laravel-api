<?php

namespace App\Http\Controllers\buyer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class LeaderBoardController extends Controller
{
    function LeaderBoard(Request $request){


        $data=DB::table("buyer_refer_earnings")->join("buyers","buyer_refer_earnings.refer_user_type","=","buyers.id")->orderBy("coins","desc")->get();


        $rank_details = array();
        $rank=0;
        foreach ($data as $value){
            $rank++;
            array_push($rank_details,[
                "buyer_id"=>$value->buyer_id,
                "rank"=>$rank,
                "amount"=>200]);
        }

        return Response::json([
            "error" => false,
            "ranks" => $rank_details
        ]);




    }
}
