<?php

namespace App\Http\Controllers;

use App\Models\Buyer;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\SellerFollowers;
use App\Models\WholesalePrice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class SellerHomePageController extends Controller
{


    function Show($id,Request $request){
        $new_data=[];
        $data=\App\Models\Seller::where("id",$id)->first();

        $new_data["postive"]=20;
        $new_data["follower"]=SellerFollowers::where("seller_id",$id)->count();
        $flag_url=DB::table("country")->where("name",$data->country)->first()->flag;
        $new_data["country"]=config("app.url")."storage/flag/".$flag_url;
        //Featured Products

        $featured_products_fetch=Product::where(["Seller_id"=>$id,"is_featured"=>1])->get();
        $featured_products=array();

        for($a=0; $a<count($featured_products_fetch); $a++){
            $p_information=[];
            $p_information["id"]=$featured_products_fetch[$a]->id;
            $p_information["product_name"]=$featured_products_fetch[$a]->product_name;

            $images=ProductImage::where("product_id",$featured_products_fetch[$a]->id)->first();
            $price=WholesalePrice::where("product_id",$featured_products_fetch[$a]->id)->first();
            $sold=Order::where("product_id","like","%".$featured_products_fetch[$a]->id."%")->get();


            if($images!=null){
                $p_information["image"]=strval(config("app.url")."storage/products/".$images->img);

            }
            if($price!=null){
                $p_information["price"]=$price->amount;

            }

            $p_information["sold"]=count($sold);


            array_push($featured_products,$p_information);

        }


        $products_fetch=Product::where("Seller_id",$id)->latest()->limit(10)->get();


        $products=array();

        for($a=0; $a<count($products_fetch); $a++){
            $p_information=[];
            $p_information["id"]=$products_fetch[$a]->id;
            $p_information["product_name"]=$products_fetch[$a]->product_name;

            $images=ProductImage::where("product_id",$products_fetch[$a]->id)->first();
            $price=WholesalePrice::where("product_id",$products_fetch[$a]->id)->first();
            $sold=Order::where("product_id","like","%".$products_fetch[$a]->id."%")->get();


            if($images!=null){
                $p_information["image"]=strval(config("app.url")."storage/products/".$images->img);

            }
            if($price!=null){
                $p_information["price"]=$price->amount;

            }

            $p_information["sold"]=count($sold);


            array_push($products,$p_information);

        }
        $new_data["featured"]=$featured_products;
        $new_data["products"]=$products;

        $last_buy=Order::where("product_id","like","%".$id."%")->latest()->first();

        if($last_buy!=null){
            $buyer=Buyer::where(["id"=>$last_buy->buyer_id])->first();

            $new_data["last_buy_user"]=$buyer->name;


            $new_data["last_buy_quantity"]=$last_buy->quantity;

        }else{
            $new_data["last_buy"]=null;
        }

        $check_is_following=SellerFollowers::where(["seller_id"=>$id,"buyer_id"=>$request->user()->id])->get();

        if(count($check_is_following)>0){
            $new_data["is_following"]=true;
        }else{
            $new_data["is_following"]=false;
        }


        return Response::json([
            "error"=>false,
            "data"=>$new_data
        ]);
    }

    function AllProducts($id){
        $products_fetch=Product::where("Seller_id",$id)->get();


        $products=array();

        for($a=0; $a<count($products_fetch); $a++){
            $p_information=[];
            $p_information["id"]=$products_fetch[$a]->id;
            $p_information["product_name"]=$products_fetch[$a]->product_name;

            $images=ProductImage::where("product_id",$products_fetch[$a]->id)->first();
            $price=WholesalePrice::where("product_id",$products_fetch[$a]->id)->first();
            $sold=Order::where("product_id","like","%".$products_fetch[$a]->id."%")->get();


            if($images!=null){
                $p_information["image"]=strval(config("app.url")."storage/products/".$images->img);

            }
            if($price!=null){
                $p_information["price"]=$price->amount;

            }

            $p_information["sold"]=count($sold);


            array_push($products,$p_information);

        }

        return Response::json([
            "errpr"=>false,
            "data"=>$products
        ]);


    }
    function NewProducts($id){
        $products_fetch=Product::where("Seller_id",$id)->latest()->get();


        $products=array();

        for($a=0; $a<count($products_fetch); $a++){
            $p_information=[];
            $p_information["id"]=$products_fetch[$a]->id;
            $p_information["product_name"]=$products_fetch[$a]->product_name;

            $images=ProductImage::where("product_id",$products_fetch[$a]->id)->first();
            $price=WholesalePrice::where("product_id",$products_fetch[$a]->id)->first();
            $sold=Order::where("product_id","like","%".$products_fetch[$a]->id."%")->get();


            if($images!=null){
                $p_information["image"]=strval(config("app.url")."storage/products/".$images->img);

            }
            if($price!=null){
                $p_information["price"]=$price->amount;

            }

            $p_information["sold"]=count($sold);


            array_push($products,$p_information);

        }

        return Response::json([
            "errpr"=>false,
            "data"=>$products
        ]);


    }

}
